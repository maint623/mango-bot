# MANGO
* 접두사 - 망고

# DB
* 사용DB : maria DB

* 봇 DB기본설정
* host: 'localhost'
* port: 3306
* user: 'root' 
* password: '    '
* database:"mango"

# HeidiSQL 설정
```
mango
└ joindata
  └ userid
  └ msgid
  └ chid
└ userdata
  └ userid
  └ date
```
![image](https://user-images.githubusercontent.com/98867089/194068368-832be19e-96e0-48d5-b3be-c6cd923e1052.png)

![image](https://user-images.githubusercontent.com/98867089/194068454-c30cf9bb-fca2-4eb6-b188-fc645b4da9ac.png)
