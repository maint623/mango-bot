var mariadb = require('mariadb');
var moment = require('moment');

const pool = mariadb.createPool({ 
  host: 'localhost', 
  port: 3306, 
  user: 'root', 
  password: '    ', 
  connectionLimit: 5,
  database:"mango"
});

exports.prove =  async function(id){
    var conn = await pool.getConnection()
    var query = "SELECT userid FROM userdata where userid='" + id +"';"; 
    var rows = await conn.query(query);
    if(rows[0] == undefined) {
      conn.end();
      return false;
    }else{
      conn.end();
      return true;
    }
};

exports.useradd =  async function(userid){
  var conn = await pool.getConnection()
  const date = moment().format("YYYY-MM-DD");
  var query = " insert into userdata (userid, date) values ('" + userid +"', '"+ date +"');"; 
  var rows = await conn.query(query);
  conn.end()
};