const { ButtonBuilder, ActionRowBuilder,EmbedBuilder } = require("discord.js")
const joindata = require("../function/joindata")
const userdata = require("../function/userdata")

module.exports = {
    name: "가입",
    aliases: ["가입"],
    run: async(client, message, args) => {
        var userdatan = await userdata.prove(message.author.id);
        if(userdatan == true) {
            message.channel.send(`이미 가입되어 있어요`)
          }else{
            var findjoindata = await joindata.findjoindata(message.author.id);
            if (findjoindata == false){

            }else{
              /*
              const channel = client.channels.fetch(`1026340007507656704`);
              console.log(channel.message.fetch())
              channel.messages.get(`1027188375519760425`).then(msg =>  
                msg.edit({ embeds: [EmbedBuilder()
                  .setColor('#0099ff')
                  .setTitle('만료 되었습니다')
                  .setDescription('이유 : 새 가입요청을 했습니다')] 
                }) 
              );
              */
              await joindata.deljoindata(message.author.id);
            }
            const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('가입하기')
            .setDescription(`${message.author.username}님 안녕하세요 가입하면 이용약관에 동의하게 됩니다!`)
      
            const row = new ActionRowBuilder().addComponents(
              new ButtonBuilder()
              .setLabel("가입")
              .setStyle(3) 
              .setCustomId("button-join"), 
        
              new ButtonBuilder()
              .setLabel("취소")
              .setStyle("Danger") 
              .setCustomId("button-notjoin"), 
      
              new ButtonBuilder()
              .setLabel("이용약관")
              .setURL("https://google.com")
              .setStyle(5)
            )
            let msg = await message.channel.send({ embeds: [embed], components: [row] })
            await joindata.createjoindata(message.author.id,msg.id,message.channel.id);
          }
    }
}