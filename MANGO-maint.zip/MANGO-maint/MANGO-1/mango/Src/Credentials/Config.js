module.exports = {
    prefix: ["망고야"],
    developersIds: ["UserId"],
    botToken: "MTAyNjg2NjIzNjc1NzM3NzExNA.GyTRc9.162o0nu2DMYKRY-i64E4p9a1yt8Q8hBBnvArJI"
}