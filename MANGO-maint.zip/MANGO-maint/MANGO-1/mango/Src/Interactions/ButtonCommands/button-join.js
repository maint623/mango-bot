const joindata = require("../../function/joindata")
const userdata = require("../../function/userdata")
const { ButtonBuilder, ActionRowBuilder,EmbedBuilder } = require("discord.js")
module.exports = {
    name : 'button-join',
    run : async(client, interaction) => {
        var findjoindata = await joindata.findjoindata(interaction.member.id);
        if(interaction.message.id == findjoindata.msgid){
            const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('성공적으로 가입을 완료했습니다')
            .setDescription('앞으로 잘 부탁드립니다!')
                    
            const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
            .setLabel("이용약관")
            .setURL("https://google.com")
            .setStyle(5)
            )
                  
            await interaction.update({ embeds: [embed], components: [row], ephemeral: false })
            await joindata.deljoindata(interaction.member.id);
            await userdata.useradd(interaction.member.id);
        }else{
            interaction.deferUpdate();
        }
    }
}