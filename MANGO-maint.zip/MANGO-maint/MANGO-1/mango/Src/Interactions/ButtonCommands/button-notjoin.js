const joindata = require("../../function/joindata")
const { ButtonBuilder, ActionRowBuilder,EmbedBuilder } = require("discord.js")
module.exports = {
    name : 'button-notjoin',
    run : async(client, interaction) => {
        var findjoindata = await joindata.findjoindata(interaction.member.id);
        if(interaction.message.id == findjoindata.msgid){
            const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('아쉽네요')
            .setDescription('가입 하시고 싶으시다면 언제든지 가입해주세요')
                    
            const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
            .setLabel("이용약관")
            .setURL("https://google.com")
            .setStyle(5)
            )
                  
            await interaction.update({ embeds: [embed], components: [row], ephemeral: false })
            await joindata.deljoindata(interaction.member.id);
        }else{
            interaction.deferUpdate();
        }
    }
}