const { ButtonBuilder, ActionRowBuilder,EmbedBuilder } = require("discord.js")
const favorability = require("../function/favorability")
const talkedRecently = new Set()
module.exports = {
    name: "안녕",
    aliases: ["hi"],
    run: async(client, message) => {
      const f = await favorability.add(talkedRecently,message.author.id,1)
      if(f==false){
        message.channel.send(`no`)
      }else{
        message.channel.send(`hi / favorability + 1`)
      }
      
    }
}