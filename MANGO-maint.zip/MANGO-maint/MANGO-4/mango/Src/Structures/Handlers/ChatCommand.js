const fs = require("fs");
const FileScanner = require('node-recursive-directory');

module.exports = async (DiscordClient, RootPath) => {
    const ScannedFiles = await FileScanner(`${RootPath}/Src/ChatCommands`)
        ScannedFiles.forEach(File => {
            if (fs.statSync(File).isDirectory()) return;
            const ChatCommands = require(File);
            if (ChatCommands.ignore) return;
            
            DiscordClient.chat.set(ChatCommands.name, ChatCommands);
            if (ChatCommands.aliases) {
                ChatCommands.aliases.forEach(Alias => {DiscordClient.chat_Aliases.set(Alias, ChatCommands.name);});
            }
        });
}