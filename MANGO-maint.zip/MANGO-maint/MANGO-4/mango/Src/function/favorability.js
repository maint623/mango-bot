const poolname = require("./pool")

exports.del =  async function(userid,num){
  const pool = await poolname.conn()
  var conn = await pool.getConnection()
  var query = "SELECT fnumber FROM favorability where userid='" + userid +"';"; 
  var rowss = await conn.query(query);
  var query = `DELETE FROM favorability WHERE userid = '${userid}';`; 
  var rows = await conn.query(query);
  var query = ` insert into favorability (userid, fnumber) values ("userid",${rowss[0].fnumber - num});`;  
  var rows = await conn.query(query);
  conn.end()
  return rowss[0].fnumber - num
};

exports.add =  async function(talkedRecently,userid,num){
  if (talkedRecently.has(userid)) {
    return false
  } else {
    talkedRecently.add(userid);
    setTimeout(() => {
      talkedRecently.delete(userid);
    }, 60*1000);
    const pool = await poolname.conn()
    var conn = await pool.getConnection()
    var query = "SELECT fnumber FROM favorability where userid='" + userid +"';"; 
    var rowss = await conn.query(query);
    var query = `DELETE FROM favorability WHERE userid = '${userid}';`; 
    var rows = await conn.query(query);
    var query = ` insert into favorability (userid, fnumber) values ("${userid}",${rowss[0].fnumber + num});`;  
    var rows = await conn.query(query);
    conn.end()
    return rowss[0].fnumber + num
  }
};

exports.find =  async function(id){
  const pool = await poolname.conn()
  var conn = await pool.getConnection()
  var query = "SELECT fnumber FROM favorability where userid='" + id +"';"; 
  var rows = await conn.query(query);
  if(rows[0] == undefined) {
    conn.end();
    return false;
  }else{
    conn.end();
    return rows[0];
  }
};