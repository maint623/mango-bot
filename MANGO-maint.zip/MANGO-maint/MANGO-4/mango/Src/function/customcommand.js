const userdata = require("./userdata")
const moment = require("moment")
const poolname = require("./pool")

exports.find =  async function(incommand,id){
  var userdatan = await userdata.prove(id);
  if(userdatan == false) { 

  }else{
    const pool = await poolname.conn()
    var conn = await pool.getConnection() 
    var query = "SELECT indata, outdata, member FROM command where indata='" + incommand +"';";
    var rows = await conn.query(query); 
    if(rows[0] == undefined) {
      conn.end();
      return false;
    }else{
      conn.end();
      return rows;
    }
  }
};

exports.add =  async function(makecommandd2,makecommandd3,tag,id){
  const date = moment().format("YYYY-MM-DD");
  const pool = await poolname.conn()
  var conn = await pool.getConnection()
  var query = "INSERT INTO command(indata, outdata, member, id, date) values('" + makecommandd2 +"','" + makecommandd3 +"','" + tag +"','" + id +"','"+ date +"');";
  var rows = await conn.query(query);
};

