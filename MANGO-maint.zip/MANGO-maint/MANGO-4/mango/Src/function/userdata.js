var moment = require('moment');
const poolname = require("./pool")

exports.prove =  async function(id){
  const pool = await poolname.conn()
    var conn = await pool.getConnection()
    var query = "SELECT userid FROM userdata where userid='" + id +"';"; 
    var rows = await conn.query(query);
    if(rows[0] == undefined) {
      conn.end();
      return false;
    }else{
      conn.end();
      return true;
    }
};

exports.useradd =  async function(userid){
  const pool = await poolname.conn()
  var conn = await pool.getConnection()
  const date = moment().format("YYYY-MM-DD");
  var query = " insert into userdata (userid, date) values ('" + userid +"', '"+ date +"');"; 
  var rows = await conn.query(query);
  var query = " insert into favorability (userid, fnumber) values ('" + userid +"', '"+ 0 +"');"; 
  var rows = await conn.query(query);
  conn.end()
};