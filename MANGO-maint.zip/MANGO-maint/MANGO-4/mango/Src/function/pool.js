var mariadb = require('mariadb');
const DB = require("../Credentials/DB");
exports.conn = async function(){
    const pool = mariadb.createPool({ 
        host: DB.host, 
        port: DB.port, 
        user: DB.user, 
        password: DB.password, 
        connectionLimit: DB.connectionLimit,
        database:DB.database
    });
    return pool
}