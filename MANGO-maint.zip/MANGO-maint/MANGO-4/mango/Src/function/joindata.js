const poolname = require("./pool")

exports.createjoindata =  async function(userid, msgid, chid){
  const pool = await poolname.conn()
  var conn = await pool.getConnection()
  var query = " insert into joindata (userid, msgid, chid) values ('" + userid +"', '"+ msgid +"' , '"+ chid +"');"; 
  var rows = await conn.query(query);
  conn.end()
};

exports.findjoindata =  async function(userid, msgid, chid){
  const pool = await poolname.conn()
  var conn = await pool.getConnection()
  var query = "SELECT * FROM joindata where userid='" + userid +"';"; 
  var rows = await conn.query(query);
  if(rows[0] == undefined) {
    conn.end();
    return false;
  }else{
    conn.end();
    return rows[0];
  }
};

exports.deljoindata =  async function(userid, msgid, chid){
  const pool = await poolname.conn()
  var conn = await pool.getConnection()
  var query = `DELETE FROM joindata WHERE userid = '${userid}';`; 
  var rows = await conn.query(query);
  conn.end()
};
