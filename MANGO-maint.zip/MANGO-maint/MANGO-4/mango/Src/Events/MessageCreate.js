const CredentialManager = require("../Credentials/Config")
const CommandOptionsVerifier = require("../Structures/CommandOptions/LoadCommandOptions")
const customcommand = require("../function/customcommand")
const userdata = require("../function/userdata")
module.exports = {
    name: "messageCreate",
    run: async(message, DiscordClient) => {
        async function ccfind(CommandName,message) {
            var userdatan = await userdata.prove(message.author.id);
            if(userdatan == true){
                var rows = await customcommand.find(CommandName,message.author.id);
                if(rows == false){
                    message.channel.send(`${CommandName}....?`)
                }else{
                    try{
                        var rlench = rows.length 
                        var randomnum = Math.floor(Math.random() * rlench)   
                    }catch{
                        var rlench = 0
                        var randomnum = rlench
                    }
                    console.log(rlench +" / "+ randomnum)
                    message.channel.send(rows[randomnum].outdata) 
                    message.channel.send("```"+rows[randomnum].member+"님이 가르쳐 주셨어요"+"```")
                }
            }
        }
        CredentialManager.prefix.forEach(Prefix => {
            if (!message.content.startsWith(Prefix)) return;
            const CommandName = message.content.toString().slice(Prefix.length).trim().split(" ")[0]
            const Command = DiscordClient.messageCommands.get(CommandName) ?? DiscordClient.messageCommands.get(DiscordClient.messageCommands_Aliases.get(CommandName))
            if (Command) {
                let args = message.content.slice(Prefix.length).trim()
                if (args.toLowerCase().startsWith(CommandName)) args = args.slice(CommandName.length).trim().split(" ")

                if (Command.limitUses && !isNaN(Command.limitUses)) {
                    const limitUsesCollection = DiscordClient.limitCommandUses
                    let LimitedUsesCount = limitUsesCollection.get(`${Command.name}_MessageCommand`) ?? -1
                    limitUsesCollection.set(`${Command.name}_MessageCommand`, Math.floor(LimitedUsesCount + 1))
                }

                if (!CommandOptionsVerifier(DiscordClient, message, Command, false, "MessageCommand")) return;

                if (Command.expireAfter && !isNaN(Command.expireAfter)) {
                    const expireAfterCollection = DiscordClient.expireAfter
                    if (!expireAfterCollection.get(`${Command.name}_MessageCommand`)) expireAfterCollection.set(`${Command.name}_MessageCommand`, Date.now())
                }

                if (Command.allowInDms) Command.run(DiscordClient, message, args)
                else if (!message.guild) return;
                else if (Command.allowBots) Command.run(DiscordClient, message, args)
                else if (message.author.bot) return;
                else Command.run(DiscordClient, message, args)
            }else{
                var colist = ["안녕","hi","잘가","bye"]
                var chtco = false 
                for (var i = 0; i < [...DiscordClient.chat.values()].length; i++) {
                    if(message.content.includes([...DiscordClient.chat.values()][i].name) == true){
                        var chtco = [...DiscordClient.chat.values()][i].name.toString()
                    }else{ 
                        if((message.content.includes([...DiscordClient.chat.values()][i].aliases) == true)){
                            var chtco = [...DiscordClient.chat.values()][i].aliases.toString()
                        }
                    }
                }
                if(chtco == false){
                    ccfind(message.content.substring(4),message)
                }else{
                    const Command = DiscordClient.chat.get(chtco) ?? DiscordClient.chat.get(DiscordClient.chat_Aliases.get(chtco))
                    if (Command.allowInDms) Command.run(DiscordClient, message)
                    else if (!message.guild) return;
                    else if (Command.allowBots) Command.run(DiscordClient, message)
                    else if (message.author.bot) return;
                    else Command.run(DiscordClient, message)
                }
                
            } 
        })
    }
}