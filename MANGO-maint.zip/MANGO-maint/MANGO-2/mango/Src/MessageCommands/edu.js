const { ButtonBuilder, ActionRowBuilder,EmbedBuilder } = require("discord.js")
const userdata = require("../function/userdata")
const customcommand = require("../function/customcommand")
module.exports = {
    name: "가르치기",
    aliases: ["가르치기"],
    run: async(client, message, args) => {
        var userdatan = await userdata.prove(message.author.id);

        if(userdatan == true) {
          var purge = message.content.substring(9) 
          var makecommandd2 = purge.split("/")[0]
          var makecommandd3 = purge.split("/")[1]

          if(makecommandd3 == undefined){
            message.channel.send("형식에 맞지 않아요")
          }else{
            if(makecommandd2 == undefined){
              message.channel.send("형식에 맞지 않아요")
            }else{
              await customcommand.add(makecommandd2,makecommandd3,message.author.tag,message.author.id);
              message.channel.send("```"+`${makecommandd2}하면.. ${makecommandd3}! 알았어요!`+"```")
            }
          }
        }else{
          message.channel.send(`가입해 주세요`)
        }
    }
}