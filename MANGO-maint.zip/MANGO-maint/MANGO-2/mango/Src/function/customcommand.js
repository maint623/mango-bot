var mariadb = require('mariadb');
const userdata = require("./userdata")
const moment = require("moment")

const pool = mariadb.createPool({ 
  host: 'localhost', 
  port: 3306, 
  user: 'root', 
  password: '    ', 
  connectionLimit: 5,
  database:"mango"
});

exports.find =  async function(incommand,id){
  var userdatan = await userdata.prove(id);
  if(userdatan == false) { 

  }else{
    var conn = await pool.getConnection() 
    var query = "SELECT indata, outdata, member FROM command where indata='" + incommand +"';";
    var rows = await conn.query(query); 
    if(rows[0] == undefined) {
      conn.end();
      return false;
    }else{
      conn.end();
      return rows;
    }
  }
};

exports.add =  async function(makecommandd2,makecommandd3,tag,id){
  const date = moment().format("YYYY-MM-DD");
  var conn = await pool.getConnection()
  var query = "INSERT INTO command(indata, outdata, member, id, date) values('" + makecommandd2 +"','" + makecommandd3 +"','" + tag +"','" + id +"','"+ date +"');";
  var rows = await conn.query(query);
};

