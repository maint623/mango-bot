const { ButtonBuilder, ActionRowBuilder,EmbedBuilder, ButtonStyle } = require("discord.js")
const request = require('request')
const { ChannelPagination, NextPageButton, PreviousPageButton } = require("djs-button-pages");
const ClientId = 'Xg07mPKk_lZhRnQvS9aB'
const ClientSecret = 'QsCbjCSzs_'
const joindata = require("../function/joindata")
const userdata = require("../function/userdata")

module.exports = {
    name: "사전",
    aliases: ["사전"],
    run: async(client, message, args) => {
        var userdatan = await userdata.prove(message.author.id);
        if(userdatan == true) {
          const option = {
            query  : `${args}`,
            sort   :'sim',
            display : 10
          }
        
          request.get({
            uri:'https://openapi.naver.com/v1/search/encyc.json',
            qs :option,
            headers:{
              'X-Naver-Client-Id':ClientId,
              'X-Naver-Client-Secret':ClientSecret
            }
          }, function(err, res, body) {
            let json = JSON.parse(body) 

            const embed1 = new EmbedBuilder()
	          .setColor(0x0099FF)
	          .setTitle(`${args} [1/2]`)
	          .setURL(`https://terms.naver.com/search.naver?query=${args}`)
	          .setDescription(`${args}에 대한 검색 결과입니다`)
	          .addFields(
	          	{ name: '1', value: `${json.items[0].description.substr(0, 30).replace("<b>", "").replace("</b>", "")}... (${json.items[0].link})` },
	          	{ name: '2', value: `${json.items[1].description.substr(0, 30).replace("<b>", "").replace("</b>", "")}... (${json.items[1].link})` },
	          	{ name: '3', value: `${json.items[2].description.substr(0, 30).replace("<b>", "").replace("</b>", "")}... (${json.items[2].link})` },
	          	{ name: '4', value: `${json.items[3].description.substr(0, 30).replace("<b>", "").replace("</b>", "")}... (${json.items[3].link})` },
	          	{ name: '5', value: `${json.items[4].description.substr(0, 30).replace("<b>", "").replace("</b>", "")}... (${json.items[4].link})` },
	          )
	          .setTimestamp()
	          .setFooter({ text: '네이버에서 가져온 검색 결과입니다'});

            const embed2 = new EmbedBuilder()
	          .setColor(0x0099FF)
	          .setTitle(`${args} [2/2]`)
	          .setURL(`https://terms.naver.com/search.naver?query=${args}`)
	          .setDescription(`${args}에 대한 검색 결과입니다`)
	          .addFields(
	          	{ name: '6', value: `${json.items[5].description.substr(0, 30).replace("<b>", "").replace("</b>", "")}... (${json.items[5].link})` },
	          	{ name: '7', value: `${json.items[6].description.substr(0, 30).replace("<b>", "").replace("</b>", "")}... (${json.items[6].link})` },
	          	{ name: '8', value: `${json.items[7].description.substr(0, 30).replace("<b>", "").replace("</b>", "")}... (${json.items[7].link})` },
	          	{ name: '9', value: `${json.items[8].description.substr(0, 30).replace("<b>", "").replace("</b>", "")}... (${json.items[8].link})` },
              { name: '10', value: `${json.items[9].description.substr(0, 30).replace("<b>", "").replace("</b>", "")}... (${json.items[9].link})` },
	          )
	          .setTimestamp()
	          .setFooter({ text: '네이버에서 가져온 검색 결과입니다'});

            const embeds = [embed1,embed2]

            const buttons = 
            [
              new PreviousPageButton({custom_id: "prev_page", label: "이전", style: ButtonStyle.Primary}),
              new NextPageButton().setStyle({custom_id: "next_page", label: "다음", style: ButtonStyle.Primary}),
            ];
            const pagination = new ChannelPagination() 
              .setButtons(buttons)
              .setEmbeds(embeds) 
              .setTime(60000);

            pagination.send(message.channel);
          })
          
        }else{
          message.channel.send(`가입 해 주세요`)
        }
    }
}

